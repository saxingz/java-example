package com.listenrobot.user.dao;

import com.listenrobot.user.domain.entity.DepartmentLineDO;

public interface DepartmentLineDOMapper {
    /**
     *  根据主键删除数据库的记录,department_line
     *
     * @param id
     */
    int deleteByPrimaryKey(Long id);

    /**
     *  新写入数据库记录,department_line
     *
     * @param record
     */
    int insert(DepartmentLineDO record);

    /**
     *  动态字段,写入数据库记录,department_line
     *
     * @param record
     */
    int insertSelective(DepartmentLineDO record);

    /**
     *  根据指定主键获取一条数据库记录,department_line
     *
     * @param id
     */
    DepartmentLineDO selectByPrimaryKey(Long id);

    /**
     *  动态字段,根据主键来更新符合条件的数据库记录,department_line
     *
     * @param record
     */
    int updateByPrimaryKeySelective(DepartmentLineDO record);

    /**
     *  根据主键来更新符合条件的数据库记录,department_line
     *
     * @param record
     */
    int updateByPrimaryKey(DepartmentLineDO record);
}