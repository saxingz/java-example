package com.listenrobot.user.domain.entity;

public class EmployeeDO {
    /**
     *  主键,所属表字段为employee.id
     */
    private Long id;

    /**
     *  企业id,所属表字段为employee.ent_id
     */
    private Integer entId;

    /**
     *  用户id,所属表字段为employee.user_id
     */
    private Long userId;

    /**
     *  企业内姓名,所属表字段为employee.name
     */
    private String name;

    /**
     *  0=不可用 1=可用 (停用),所属表字段为employee.status
     */
    private Byte status;

    /**
     *  个人线索数,所属表字段为employee.clue_number
     */
    private Integer clueNumber;

    /**
     *  1= 已删除 0=未删除,所属表字段为employee.is_delete
     */
    private Byte isDelete;

    /**
     * 获取 主键 字段:employee.id
     *
     * @return employee.id, 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 主键 字段:employee.id
     *
     * @param id employee.id, 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 企业id 字段:employee.ent_id
     *
     * @return employee.ent_id, 企业id
     */
    public Integer getEntId() {
        return entId;
    }

    /**
     * 设置 企业id 字段:employee.ent_id
     *
     * @param entId employee.ent_id, 企业id
     */
    public void setEntId(Integer entId) {
        this.entId = entId;
    }

    /**
     * 获取 用户id 字段:employee.user_id
     *
     * @return employee.user_id, 用户id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置 用户id 字段:employee.user_id
     *
     * @param userId employee.user_id, 用户id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取 企业内姓名 字段:employee.name
     *
     * @return employee.name, 企业内姓名
     */
    public String getName() {
        return name;
    }

    /**
     * 设置 企业内姓名 字段:employee.name
     *
     * @param name employee.name, 企业内姓名
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 获取 0=不可用 1=可用 (停用) 字段:employee.status
     *
     * @return employee.status, 0=不可用 1=可用 (停用)
     */
    public Byte getStatus() {
        return status;
    }

    /**
     * 设置 0=不可用 1=可用 (停用) 字段:employee.status
     *
     * @param status employee.status, 0=不可用 1=可用 (停用)
     */
    public void setStatus(Byte status) {
        this.status = status;
    }

    /**
     * 获取 个人线索数 字段:employee.clue_number
     *
     * @return employee.clue_number, 个人线索数
     */
    public Integer getClueNumber() {
        return clueNumber;
    }

    /**
     * 设置 个人线索数 字段:employee.clue_number
     *
     * @param clueNumber employee.clue_number, 个人线索数
     */
    public void setClueNumber(Integer clueNumber) {
        this.clueNumber = clueNumber;
    }

    /**
     * 获取 1= 已删除 0=未删除 字段:employee.is_delete
     *
     * @return employee.is_delete, 1= 已删除 0=未删除
     */
    public Byte getIsDelete() {
        return isDelete;
    }

    /**
     * 设置 1= 已删除 0=未删除 字段:employee.is_delete
     *
     * @param isDelete employee.is_delete, 1= 已删除 0=未删除
     */
    public void setIsDelete(Byte isDelete) {
        this.isDelete = isDelete;
    }
}