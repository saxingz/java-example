package com.listenrobot.user.domain.entity;

public class DepartmentDO {
    /**
     *  部门ID,所属表字段为department.id
     */
    private Long id;

    /**
     *  企业id,所属表字段为department.ent_id
     */
    private Long entId;

    /**
     *  部门名称,所属表字段为department.name
     */
    private String name;

    /**
     *  父部门ID,所属表字段为department.parent_id
     */
    private Long parentId;

    /**
     *  在父部门的次序,所属表字段为department.sort
     */
    private Integer sort;

    /**
     *  是否已删除（0：未删除1：已删除）,所属表字段为department.is_deleted
     */
    private Byte isDeleted;

    /**
     *  部门类型：1、部门；2、坐席班组；3临时坐席班组,所属表字段为department.type
     */
    private Byte type;

    /**
     * 获取 部门ID 字段:department.id
     *
     * @return department.id, 部门ID
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 部门ID 字段:department.id
     *
     * @param id department.id, 部门ID
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 企业id 字段:department.ent_id
     *
     * @return department.ent_id, 企业id
     */
    public Long getEntId() {
        return entId;
    }

    /**
     * 设置 企业id 字段:department.ent_id
     *
     * @param entId department.ent_id, 企业id
     */
    public void setEntId(Long entId) {
        this.entId = entId;
    }

    /**
     * 获取 部门名称 字段:department.name
     *
     * @return department.name, 部门名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置 部门名称 字段:department.name
     *
     * @param name department.name, 部门名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * 获取 父部门ID 字段:department.parent_id
     *
     * @return department.parent_id, 父部门ID
     */
    public Long getParentId() {
        return parentId;
    }

    /**
     * 设置 父部门ID 字段:department.parent_id
     *
     * @param parentId department.parent_id, 父部门ID
     */
    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    /**
     * 获取 在父部门的次序 字段:department.sort
     *
     * @return department.sort, 在父部门的次序
     */
    public Integer getSort() {
        return sort;
    }

    /**
     * 设置 在父部门的次序 字段:department.sort
     *
     * @param sort department.sort, 在父部门的次序
     */
    public void setSort(Integer sort) {
        this.sort = sort;
    }

    /**
     * 获取 是否已删除（0：未删除1：已删除） 字段:department.is_deleted
     *
     * @return department.is_deleted, 是否已删除（0：未删除1：已删除）
     */
    public Byte getIsDeleted() {
        return isDeleted;
    }

    /**
     * 设置 是否已删除（0：未删除1：已删除） 字段:department.is_deleted
     *
     * @param isDeleted department.is_deleted, 是否已删除（0：未删除1：已删除）
     */
    public void setIsDeleted(Byte isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * 获取 部门类型：1、部门；2、坐席班组；3临时坐席班组 字段:department.type
     *
     * @return department.type, 部门类型：1、部门；2、坐席班组；3临时坐席班组
     */
    public Byte getType() {
        return type;
    }

    /**
     * 设置 部门类型：1、部门；2、坐席班组；3临时坐席班组 字段:department.type
     *
     * @param type department.type, 部门类型：1、部门；2、坐席班组；3临时坐席班组
     */
    public void setType(Byte type) {
        this.type = type;
    }
}