package com.listenrobot.user.dao;

import com.listenrobot.user.domain.entity.AgentDO;

public interface AgentDOMapper {
    /**
     *  根据主键删除数据库的记录,agent
     *
     * @param id
     */
    int deleteByPrimaryKey(Long id);

    /**
     *  新写入数据库记录,agent
     *
     * @param record
     */
    int insert(AgentDO record);

    /**
     *  动态字段,写入数据库记录,agent
     *
     * @param record
     */
    int insertSelective(AgentDO record);

    /**
     *  根据指定主键获取一条数据库记录,agent
     *
     * @param id
     */
    AgentDO selectByPrimaryKey(Long id);

    /**
     *  动态字段,根据主键来更新符合条件的数据库记录,agent
     *
     * @param record
     */
    int updateByPrimaryKeySelective(AgentDO record);

    /**
     *  根据主键来更新符合条件的数据库记录,agent
     *
     * @param record
     */
    int updateByPrimaryKey(AgentDO record);
}