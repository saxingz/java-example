package com.listenrobot.user.domain.entity;

import java.util.Date;

public class EnterpriseDO {
    /**
     *  企业id,所属表字段为enterprise.id
     */
    private Long id;

    /**
     *  管理员的user_id,所属表字段为enterprise.admin_id
     */
    private Long adminId;

    /**
     *  企业名称,所属表字段为enterprise.ent_name
     */
    private String entName;

    /**
     *  代理商id,所属表字段为enterprise.agent_id
     */
    private Long agentId;

    /**
     *  代理商名字,所属表字段为enterprise.agent_name
     */
    private String agentName;

    /**
     *  是否是开发者,所属表字段为enterprise.is_developer
     */
    private Byte isDeveloper;

    /**
     *  开发者类型(0:企业，1：ISV),所属表字段为enterprise.developer_type
     */
    private Byte developerType;

    /**
     *  机器人数,所属表字段为enterprise.ai_number
     */
    private Integer aiNumber;

    /**
     *  剩余ai数,所属表字段为enterprise.left_ai
     */
    private Integer leftAi;

    /**
     *  企业私有线索数,所属表字段为enterprise.private_clue_number
     */
    private Integer privateClueNumber;

    /**
     *  企业共享线索数,所属表字段为enterprise.public_clue_number
     */
    private Integer publicClueNumber;

    /**
     *  线路数,所属表字段为enterprise.channel
     */
    private Integer channel;

    /**
     *  剩余线路数,所属表字段为enterprise.left_channel
     */
    private Integer leftChannel;

    /**
     *  生效时间,所属表字段为enterprise.valid_time
     */
    private Date validTime;

    /**
     *  失效日期,所属表字段为enterprise.expire_time
     */
    private Date expireTime;

    /**
     *  0:未激活，1已激活,所属表字段为enterprise.active
     */
    private Byte active;

    /**
     *  是否已删除（0：未删除1：已删除）,所属表字段为enterprise.is_delete
     */
    private Integer isDelete;

    /**
     *  创建人,所属表字段为enterprise.create_by
     */
    private Long createBy;

    /**
     *  更新人,所属表字段为enterprise.update_by
     */
    private Long updateBy;

    /**
     *  企业私有线索数剩余量,所属表字段为enterprise.left_private_clue
     */
    private Integer leftPrivateClue;

    /**
     *  企业私有线索数剩余量,所属表字段为enterprise.left_public_clue
     */
    private Integer leftPublicClue;

    /**
     * 获取 企业id 字段:enterprise.id
     *
     * @return enterprise.id, 企业id
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 企业id 字段:enterprise.id
     *
     * @param id enterprise.id, 企业id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 管理员的user_id 字段:enterprise.admin_id
     *
     * @return enterprise.admin_id, 管理员的user_id
     */
    public Long getAdminId() {
        return adminId;
    }

    /**
     * 设置 管理员的user_id 字段:enterprise.admin_id
     *
     * @param adminId enterprise.admin_id, 管理员的user_id
     */
    public void setAdminId(Long adminId) {
        this.adminId = adminId;
    }

    /**
     * 获取 企业名称 字段:enterprise.ent_name
     *
     * @return enterprise.ent_name, 企业名称
     */
    public String getEntName() {
        return entName;
    }

    /**
     * 设置 企业名称 字段:enterprise.ent_name
     *
     * @param entName enterprise.ent_name, 企业名称
     */
    public void setEntName(String entName) {
        this.entName = entName == null ? null : entName.trim();
    }

    /**
     * 获取 代理商id 字段:enterprise.agent_id
     *
     * @return enterprise.agent_id, 代理商id
     */
    public Long getAgentId() {
        return agentId;
    }

    /**
     * 设置 代理商id 字段:enterprise.agent_id
     *
     * @param agentId enterprise.agent_id, 代理商id
     */
    public void setAgentId(Long agentId) {
        this.agentId = agentId;
    }

    /**
     * 获取 代理商名字 字段:enterprise.agent_name
     *
     * @return enterprise.agent_name, 代理商名字
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * 设置 代理商名字 字段:enterprise.agent_name
     *
     * @param agentName enterprise.agent_name, 代理商名字
     */
    public void setAgentName(String agentName) {
        this.agentName = agentName == null ? null : agentName.trim();
    }

    /**
     * 获取 是否是开发者 字段:enterprise.is_developer
     *
     * @return enterprise.is_developer, 是否是开发者
     */
    public Byte getIsDeveloper() {
        return isDeveloper;
    }

    /**
     * 设置 是否是开发者 字段:enterprise.is_developer
     *
     * @param isDeveloper enterprise.is_developer, 是否是开发者
     */
    public void setIsDeveloper(Byte isDeveloper) {
        this.isDeveloper = isDeveloper;
    }

    /**
     * 获取 开发者类型(0:企业，1：ISV) 字段:enterprise.developer_type
     *
     * @return enterprise.developer_type, 开发者类型(0:企业，1：ISV)
     */
    public Byte getDeveloperType() {
        return developerType;
    }

    /**
     * 设置 开发者类型(0:企业，1：ISV) 字段:enterprise.developer_type
     *
     * @param developerType enterprise.developer_type, 开发者类型(0:企业，1：ISV)
     */
    public void setDeveloperType(Byte developerType) {
        this.developerType = developerType;
    }

    /**
     * 获取 机器人数 字段:enterprise.ai_number
     *
     * @return enterprise.ai_number, 机器人数
     */
    public Integer getAiNumber() {
        return aiNumber;
    }

    /**
     * 设置 机器人数 字段:enterprise.ai_number
     *
     * @param aiNumber enterprise.ai_number, 机器人数
     */
    public void setAiNumber(Integer aiNumber) {
        this.aiNumber = aiNumber;
    }

    /**
     * 获取 剩余ai数 字段:enterprise.left_ai
     *
     * @return enterprise.left_ai, 剩余ai数
     */
    public Integer getLeftAi() {
        return leftAi;
    }

    /**
     * 设置 剩余ai数 字段:enterprise.left_ai
     *
     * @param leftAi enterprise.left_ai, 剩余ai数
     */
    public void setLeftAi(Integer leftAi) {
        this.leftAi = leftAi;
    }

    /**
     * 获取 企业私有线索数 字段:enterprise.private_clue_number
     *
     * @return enterprise.private_clue_number, 企业私有线索数
     */
    public Integer getPrivateClueNumber() {
        return privateClueNumber;
    }

    /**
     * 设置 企业私有线索数 字段:enterprise.private_clue_number
     *
     * @param privateClueNumber enterprise.private_clue_number, 企业私有线索数
     */
    public void setPrivateClueNumber(Integer privateClueNumber) {
        this.privateClueNumber = privateClueNumber;
    }

    /**
     * 获取 企业共享线索数 字段:enterprise.public_clue_number
     *
     * @return enterprise.public_clue_number, 企业共享线索数
     */
    public Integer getPublicClueNumber() {
        return publicClueNumber;
    }

    /**
     * 设置 企业共享线索数 字段:enterprise.public_clue_number
     *
     * @param publicClueNumber enterprise.public_clue_number, 企业共享线索数
     */
    public void setPublicClueNumber(Integer publicClueNumber) {
        this.publicClueNumber = publicClueNumber;
    }

    /**
     * 获取 线路数 字段:enterprise.channel
     *
     * @return enterprise.channel, 线路数
     */
    public Integer getChannel() {
        return channel;
    }

    /**
     * 设置 线路数 字段:enterprise.channel
     *
     * @param channel enterprise.channel, 线路数
     */
    public void setChannel(Integer channel) {
        this.channel = channel;
    }

    /**
     * 获取 剩余线路数 字段:enterprise.left_channel
     *
     * @return enterprise.left_channel, 剩余线路数
     */
    public Integer getLeftChannel() {
        return leftChannel;
    }

    /**
     * 设置 剩余线路数 字段:enterprise.left_channel
     *
     * @param leftChannel enterprise.left_channel, 剩余线路数
     */
    public void setLeftChannel(Integer leftChannel) {
        this.leftChannel = leftChannel;
    }

    /**
     * 获取 生效时间 字段:enterprise.valid_time
     *
     * @return enterprise.valid_time, 生效时间
     */
    public Date getValidTime() {
        return validTime;
    }

    /**
     * 设置 生效时间 字段:enterprise.valid_time
     *
     * @param validTime enterprise.valid_time, 生效时间
     */
    public void setValidTime(Date validTime) {
        this.validTime = validTime;
    }

    /**
     * 获取 失效日期 字段:enterprise.expire_time
     *
     * @return enterprise.expire_time, 失效日期
     */
    public Date getExpireTime() {
        return expireTime;
    }

    /**
     * 设置 失效日期 字段:enterprise.expire_time
     *
     * @param expireTime enterprise.expire_time, 失效日期
     */
    public void setExpireTime(Date expireTime) {
        this.expireTime = expireTime;
    }

    /**
     * 获取 0:未激活，1已激活 字段:enterprise.active
     *
     * @return enterprise.active, 0:未激活，1已激活
     */
    public Byte getActive() {
        return active;
    }

    /**
     * 设置 0:未激活，1已激活 字段:enterprise.active
     *
     * @param active enterprise.active, 0:未激活，1已激活
     */
    public void setActive(Byte active) {
        this.active = active;
    }

    /**
     * 获取 是否已删除（0：未删除1：已删除） 字段:enterprise.is_delete
     *
     * @return enterprise.is_delete, 是否已删除（0：未删除1：已删除）
     */
    public Integer getIsDelete() {
        return isDelete;
    }

    /**
     * 设置 是否已删除（0：未删除1：已删除） 字段:enterprise.is_delete
     *
     * @param isDelete enterprise.is_delete, 是否已删除（0：未删除1：已删除）
     */
    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    /**
     * 获取 创建人 字段:enterprise.create_by
     *
     * @return enterprise.create_by, 创建人
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * 设置 创建人 字段:enterprise.create_by
     *
     * @param createBy enterprise.create_by, 创建人
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * 获取 更新人 字段:enterprise.update_by
     *
     * @return enterprise.update_by, 更新人
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * 设置 更新人 字段:enterprise.update_by
     *
     * @param updateBy enterprise.update_by, 更新人
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * 获取 企业私有线索数剩余量 字段:enterprise.left_private_clue
     *
     * @return enterprise.left_private_clue, 企业私有线索数剩余量
     */
    public Integer getLeftPrivateClue() {
        return leftPrivateClue;
    }

    /**
     * 设置 企业私有线索数剩余量 字段:enterprise.left_private_clue
     *
     * @param leftPrivateClue enterprise.left_private_clue, 企业私有线索数剩余量
     */
    public void setLeftPrivateClue(Integer leftPrivateClue) {
        this.leftPrivateClue = leftPrivateClue;
    }

    /**
     * 获取 企业私有线索数剩余量 字段:enterprise.left_public_clue
     *
     * @return enterprise.left_public_clue, 企业私有线索数剩余量
     */
    public Integer getLeftPublicClue() {
        return leftPublicClue;
    }

    /**
     * 设置 企业私有线索数剩余量 字段:enterprise.left_public_clue
     *
     * @param leftPublicClue enterprise.left_public_clue, 企业私有线索数剩余量
     */
    public void setLeftPublicClue(Integer leftPublicClue) {
        this.leftPublicClue = leftPublicClue;
    }
}