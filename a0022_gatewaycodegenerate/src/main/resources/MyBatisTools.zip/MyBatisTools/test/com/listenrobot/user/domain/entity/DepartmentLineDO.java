package com.listenrobot.user.domain.entity;

public class DepartmentLineDO {
    /**
     *  主键,所属表字段为department_line.id
     */
    private Long id;

    /**
     *  企业id,所属表字段为department_line.ent_id
     */
    private Integer entId;

    /**
     *  部门id,所属表字段为department_line.department_id
     */
    private Long departmentId;

    /**
     *  主叫号码,所属表字段为department_line.calling_number
     */
    private String callingNumber;

    /**
     *  号码线路数,所属表字段为department_line.line_number
     */
    private Integer lineNumber;

    /**
     *  主叫号码剩余线路数,所属表字段为department_line.left_line
     */
    private Integer leftLine;

    /**
     * 获取 主键 字段:department_line.id
     *
     * @return department_line.id, 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 主键 字段:department_line.id
     *
     * @param id department_line.id, 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 企业id 字段:department_line.ent_id
     *
     * @return department_line.ent_id, 企业id
     */
    public Integer getEntId() {
        return entId;
    }

    /**
     * 设置 企业id 字段:department_line.ent_id
     *
     * @param entId department_line.ent_id, 企业id
     */
    public void setEntId(Integer entId) {
        this.entId = entId;
    }

    /**
     * 获取 部门id 字段:department_line.department_id
     *
     * @return department_line.department_id, 部门id
     */
    public Long getDepartmentId() {
        return departmentId;
    }

    /**
     * 设置 部门id 字段:department_line.department_id
     *
     * @param departmentId department_line.department_id, 部门id
     */
    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * 获取 主叫号码 字段:department_line.calling_number
     *
     * @return department_line.calling_number, 主叫号码
     */
    public String getCallingNumber() {
        return callingNumber;
    }

    /**
     * 设置 主叫号码 字段:department_line.calling_number
     *
     * @param callingNumber department_line.calling_number, 主叫号码
     */
    public void setCallingNumber(String callingNumber) {
        this.callingNumber = callingNumber == null ? null : callingNumber.trim();
    }

    /**
     * 获取 号码线路数 字段:department_line.line_number
     *
     * @return department_line.line_number, 号码线路数
     */
    public Integer getLineNumber() {
        return lineNumber;
    }

    /**
     * 设置 号码线路数 字段:department_line.line_number
     *
     * @param lineNumber department_line.line_number, 号码线路数
     */
    public void setLineNumber(Integer lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
     * 获取 主叫号码剩余线路数 字段:department_line.left_line
     *
     * @return department_line.left_line, 主叫号码剩余线路数
     */
    public Integer getLeftLine() {
        return leftLine;
    }

    /**
     * 设置 主叫号码剩余线路数 字段:department_line.left_line
     *
     * @param leftLine department_line.left_line, 主叫号码剩余线路数
     */
    public void setLeftLine(Integer leftLine) {
        this.leftLine = leftLine;
    }
}