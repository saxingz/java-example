package com.listenrobot.user.domain.entity;

public class DepartmentUserDO {
    /**
     *  主键id,所属表字段为department_user.id
     */
    private Long id;

    /**
     *  企业id,所属表字段为department_user.ent_id
     */
    private Long entId;

    /**
     *  企业名称,所属表字段为department_user.ent_name
     */
    private String entName;

    /**
     *  部门id,所属表字段为department_user.department_id
     */
    private Long departmentId;

    /**
     *  部门名称,所属表字段为department_user.department_name
     */
    private String departmentName;

    /**
     *  用户id,所属表字段为department_user.user_id
     */
    private Long userId;

    /**
     *  用户名称,所属表字段为department_user.employee_name
     */
    private String employeeName;

    /**
     *  岗位： 0=普通 1=主管 ,所属表字段为department_user.station_type
     */
    private Byte stationType;

    /**
     * 获取 主键id 字段:department_user.id
     *
     * @return department_user.id, 主键id
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 主键id 字段:department_user.id
     *
     * @param id department_user.id, 主键id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 企业id 字段:department_user.ent_id
     *
     * @return department_user.ent_id, 企业id
     */
    public Long getEntId() {
        return entId;
    }

    /**
     * 设置 企业id 字段:department_user.ent_id
     *
     * @param entId department_user.ent_id, 企业id
     */
    public void setEntId(Long entId) {
        this.entId = entId;
    }

    /**
     * 获取 企业名称 字段:department_user.ent_name
     *
     * @return department_user.ent_name, 企业名称
     */
    public String getEntName() {
        return entName;
    }

    /**
     * 设置 企业名称 字段:department_user.ent_name
     *
     * @param entName department_user.ent_name, 企业名称
     */
    public void setEntName(String entName) {
        this.entName = entName == null ? null : entName.trim();
    }

    /**
     * 获取 部门id 字段:department_user.department_id
     *
     * @return department_user.department_id, 部门id
     */
    public Long getDepartmentId() {
        return departmentId;
    }

    /**
     * 设置 部门id 字段:department_user.department_id
     *
     * @param departmentId department_user.department_id, 部门id
     */
    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * 获取 部门名称 字段:department_user.department_name
     *
     * @return department_user.department_name, 部门名称
     */
    public String getDepartmentName() {
        return departmentName;
    }

    /**
     * 设置 部门名称 字段:department_user.department_name
     *
     * @param departmentName department_user.department_name, 部门名称
     */
    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName == null ? null : departmentName.trim();
    }

    /**
     * 获取 用户id 字段:department_user.user_id
     *
     * @return department_user.user_id, 用户id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置 用户id 字段:department_user.user_id
     *
     * @param userId department_user.user_id, 用户id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * 获取 用户名称 字段:department_user.employee_name
     *
     * @return department_user.employee_name, 用户名称
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * 设置 用户名称 字段:department_user.employee_name
     *
     * @param employeeName department_user.employee_name, 用户名称
     */
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName == null ? null : employeeName.trim();
    }

    /**
     * 获取 岗位： 0=普通 1=主管  字段:department_user.station_type
     *
     * @return department_user.station_type, 岗位： 0=普通 1=主管 
     */
    public Byte getStationType() {
        return stationType;
    }

    /**
     * 设置 岗位： 0=普通 1=主管  字段:department_user.station_type
     *
     * @param stationType department_user.station_type, 岗位： 0=普通 1=主管 
     */
    public void setStationType(Byte stationType) {
        this.stationType = stationType;
    }
}