package com.listenrobot.user.domain.entity;

public class DepartmentPropertyDO {
    /**
     *  主键,所属表字段为department_property.id
     */
    private Long id;

    /**
     *  部门id,所属表字段为department_property.department_id
     */
    private Long departmentId;

    /**
     *  企业id,所属表字段为department_property.ent_id
     */
    private Integer entId;

    /**
     *  拥有ai数,所属表字段为department_property.ai_number
     */
    private Integer aiNumber;

    /**
     *  剩余ai数,所属表字段为department_property.left_ai
     */
    private Integer leftAi;

    /**
     *  线路数,所属表字段为department_property.channel_number
     */
    private Integer channelNumber;

    /**
     *  剩余线路数,所属表字段为department_property.left_channel
     */
    private Integer leftChannel;

    /**
     * 获取 主键 字段:department_property.id
     *
     * @return department_property.id, 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 主键 字段:department_property.id
     *
     * @param id department_property.id, 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 部门id 字段:department_property.department_id
     *
     * @return department_property.department_id, 部门id
     */
    public Long getDepartmentId() {
        return departmentId;
    }

    /**
     * 设置 部门id 字段:department_property.department_id
     *
     * @param departmentId department_property.department_id, 部门id
     */
    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * 获取 企业id 字段:department_property.ent_id
     *
     * @return department_property.ent_id, 企业id
     */
    public Integer getEntId() {
        return entId;
    }

    /**
     * 设置 企业id 字段:department_property.ent_id
     *
     * @param entId department_property.ent_id, 企业id
     */
    public void setEntId(Integer entId) {
        this.entId = entId;
    }

    /**
     * 获取 拥有ai数 字段:department_property.ai_number
     *
     * @return department_property.ai_number, 拥有ai数
     */
    public Integer getAiNumber() {
        return aiNumber;
    }

    /**
     * 设置 拥有ai数 字段:department_property.ai_number
     *
     * @param aiNumber department_property.ai_number, 拥有ai数
     */
    public void setAiNumber(Integer aiNumber) {
        this.aiNumber = aiNumber;
    }

    /**
     * 获取 剩余ai数 字段:department_property.left_ai
     *
     * @return department_property.left_ai, 剩余ai数
     */
    public Integer getLeftAi() {
        return leftAi;
    }

    /**
     * 设置 剩余ai数 字段:department_property.left_ai
     *
     * @param leftAi department_property.left_ai, 剩余ai数
     */
    public void setLeftAi(Integer leftAi) {
        this.leftAi = leftAi;
    }

    /**
     * 获取 线路数 字段:department_property.channel_number
     *
     * @return department_property.channel_number, 线路数
     */
    public Integer getChannelNumber() {
        return channelNumber;
    }

    /**
     * 设置 线路数 字段:department_property.channel_number
     *
     * @param channelNumber department_property.channel_number, 线路数
     */
    public void setChannelNumber(Integer channelNumber) {
        this.channelNumber = channelNumber;
    }

    /**
     * 获取 剩余线路数 字段:department_property.left_channel
     *
     * @return department_property.left_channel, 剩余线路数
     */
    public Integer getLeftChannel() {
        return leftChannel;
    }

    /**
     * 设置 剩余线路数 字段:department_property.left_channel
     *
     * @param leftChannel department_property.left_channel, 剩余线路数
     */
    public void setLeftChannel(Integer leftChannel) {
        this.leftChannel = leftChannel;
    }
}