package com.listenrobot.user.dao;

import com.listenrobot.user.domain.entity.EnterpriseDO;

public interface EnterpriseDOMapper {
    /**
     *  根据主键删除数据库的记录,enterprise
     *
     * @param id
     */
    int deleteByPrimaryKey(Long id);

    /**
     *  新写入数据库记录,enterprise
     *
     * @param record
     */
    int insert(EnterpriseDO record);

    /**
     *  动态字段,写入数据库记录,enterprise
     *
     * @param record
     */
    int insertSelective(EnterpriseDO record);

    /**
     *  根据指定主键获取一条数据库记录,enterprise
     *
     * @param id
     */
    EnterpriseDO selectByPrimaryKey(Long id);

    /**
     *  动态字段,根据主键来更新符合条件的数据库记录,enterprise
     *
     * @param record
     */
    int updateByPrimaryKeySelective(EnterpriseDO record);

    /**
     *  根据主键来更新符合条件的数据库记录,enterprise
     *
     * @param record
     */
    int updateByPrimaryKey(EnterpriseDO record);
}