package com.listenrobot.user.domain.entity;

public class AgentDO {
    /**
     *  坐席id,所属表字段为agent.id
     */
    private Long id;

    /**
     *  企业id,所属表字段为agent.ent_id
     */
    private Long entId;

    /**
     *  坐席名称,所属表字段为agent.agent_name
     */
    private String agentName;

    /**
     *  分机号码,所属表字段为agent.extension_number
     */
    private String extensionNumber;

    /**
     *  0:管理员坐席，1：班长坐席，2：业务员坐席,所属表字段为agent.seat_role
     */
    private Byte seatRole;

    /**
     *  是否已删除（0：未删除1：已删除）,所属表字段为agent.is_delete
     */
    private Integer isDelete;

    /**
     *  所属坐席组,所属表字段为agent.department_id
     */
    private Long departmentId;

    /**
     *  坐席号码,所属表字段为agent.agent_number
     */
    private String agentNumber;

    /**
     *  用户id,所属表字段为agent.user_id
     */
    private Long userId;

    /**
     * 获取 坐席id 字段:agent.id
     *
     * @return agent.id, 坐席id
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置 坐席id 字段:agent.id
     *
     * @param id agent.id, 坐席id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取 企业id 字段:agent.ent_id
     *
     * @return agent.ent_id, 企业id
     */
    public Long getEntId() {
        return entId;
    }

    /**
     * 设置 企业id 字段:agent.ent_id
     *
     * @param entId agent.ent_id, 企业id
     */
    public void setEntId(Long entId) {
        this.entId = entId;
    }

    /**
     * 获取 坐席名称 字段:agent.agent_name
     *
     * @return agent.agent_name, 坐席名称
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * 设置 坐席名称 字段:agent.agent_name
     *
     * @param agentName agent.agent_name, 坐席名称
     */
    public void setAgentName(String agentName) {
        this.agentName = agentName == null ? null : agentName.trim();
    }

    /**
     * 获取 分机号码 字段:agent.extension_number
     *
     * @return agent.extension_number, 分机号码
     */
    public String getExtensionNumber() {
        return extensionNumber;
    }

    /**
     * 设置 分机号码 字段:agent.extension_number
     *
     * @param extensionNumber agent.extension_number, 分机号码
     */
    public void setExtensionNumber(String extensionNumber) {
        this.extensionNumber = extensionNumber == null ? null : extensionNumber.trim();
    }

    /**
     * 获取 0:管理员坐席，1：班长坐席，2：业务员坐席 字段:agent.seat_role
     *
     * @return agent.seat_role, 0:管理员坐席，1：班长坐席，2：业务员坐席
     */
    public Byte getSeatRole() {
        return seatRole;
    }

    /**
     * 设置 0:管理员坐席，1：班长坐席，2：业务员坐席 字段:agent.seat_role
     *
     * @param seatRole agent.seat_role, 0:管理员坐席，1：班长坐席，2：业务员坐席
     */
    public void setSeatRole(Byte seatRole) {
        this.seatRole = seatRole;
    }

    /**
     * 获取 是否已删除（0：未删除1：已删除） 字段:agent.is_delete
     *
     * @return agent.is_delete, 是否已删除（0：未删除1：已删除）
     */
    public Integer getIsDelete() {
        return isDelete;
    }

    /**
     * 设置 是否已删除（0：未删除1：已删除） 字段:agent.is_delete
     *
     * @param isDelete agent.is_delete, 是否已删除（0：未删除1：已删除）
     */
    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    /**
     * 获取 所属坐席组 字段:agent.department_id
     *
     * @return agent.department_id, 所属坐席组
     */
    public Long getDepartmentId() {
        return departmentId;
    }

    /**
     * 设置 所属坐席组 字段:agent.department_id
     *
     * @param departmentId agent.department_id, 所属坐席组
     */
    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    /**
     * 获取 坐席号码 字段:agent.agent_number
     *
     * @return agent.agent_number, 坐席号码
     */
    public String getAgentNumber() {
        return agentNumber;
    }

    /**
     * 设置 坐席号码 字段:agent.agent_number
     *
     * @param agentNumber agent.agent_number, 坐席号码
     */
    public void setAgentNumber(String agentNumber) {
        this.agentNumber = agentNumber == null ? null : agentNumber.trim();
    }

    /**
     * 获取 用户id 字段:agent.user_id
     *
     * @return agent.user_id, 用户id
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * 设置 用户id 字段:agent.user_id
     *
     * @param userId agent.user_id, 用户id
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }
}